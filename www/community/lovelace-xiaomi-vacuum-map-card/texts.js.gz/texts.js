const textMode = "Mode";
const textGoToTarget = "Go to target";
const textZonedCleanup = "Zoned cleanup";
const textZones = "Zones";
const textRun = "Start";
const textRepeats = "Times:";
const textConfirmation = "Command sent!";

export {
    textMode,
    textGoToTarget,
    textZonedCleanup,
    textZones,
    textRun,
    textRepeats,
    textConfirmation
};